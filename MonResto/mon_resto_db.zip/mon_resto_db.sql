-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 10 mai 2022 à 01:22
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mon_resto_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `resto_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `user_id` (`user_id`),
  KEY `resto_id` (`resto_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `resto_id`, `user_id`, `email`, `password`) VALUES
(1, 'judi', 1, 2, 'ino@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e');

-- --------------------------------------------------------

--
-- Structure de la table `cmd`
--

DROP TABLE IF EXISTS `cmd`;
CREATE TABLE IF NOT EXISTS `cmd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prix` int(11) DEFAULT NULL,
  `type_cmd` varchar(255) DEFAULT NULL,
  `resto_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cmd`
--

INSERT INTO `cmd` (`id`, `nom`, `prix`, `type_cmd`, `resto_id`) VALUES
(1, 'lait', 500, 'petit-dej', 1),
(2, 'pain de mie', 200, 'petit-dej', 1),
(3, 'vin rouge', 5000, 'boisson', 1),
(4, 'vin blanc', 90000, 'boisson', 1),
(5, 'the +pain complet legerement beurre + petit morceau de fromage+1 pomme', 500, 'dejene', 1),
(6, 'cafe + muesli sans sucre ajoute + lait tiede  + 1 poire en morceaux + une poignée d\'amandes et noix', 1000, 'dejene', 1),
(7, 'un grand verre d\'eau + pain noir + 1 oeuf coque + 1 yaourt nature + 125g de fraise', 900, 'dejene', 3),
(8, 'cafe + muesli sans sucre ajoute + lait tiede  + 1 poire en morceaux + une poignée d\'amandes et noix', 1300, 'dejene', 3),
(9, 'pain de mie', 200, 'petit-dej', 3),
(10, 'the', 100, 'petit-dej', 3),
(11, 'vin blanc', 8000, 'boisson', 3),
(12, 'champagne', 10000, 'boisson', 3),
(13, 'omelette au fromage', 500, 'dine', 1),
(14, 'pomme de terre farcie aux lardon et brocoli', 9000, 'dine', 1),
(15, 'salade de pates au thon tomate et mais', 5000, 'dine', 1),
(16, 'pizza au poulet et fromage', 5000, 'dine', 1),
(17, 'riz au lait', 2000, 'dine', 3),
(18, 'veloute froid à la betterave et feta', 3000, 'dine', 3);

-- --------------------------------------------------------

--
-- Structure de la table `mes_resto`
--

DROP TABLE IF EXISTS `mes_resto`;
CREATE TABLE IF NOT EXISTS `mes_resto` (
  `resto_id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_resto` varchar(255) NOT NULL,
  `image_resto` varchar(255) NOT NULL,
  `localisation_resto` varchar(255) NOT NULL,
  `description_resto` varchar(255) NOT NULL,
  `tel_resto` varchar(255) NOT NULL,
  PRIMARY KEY (`resto_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mes_resto`
--

INSERT INTO `mes_resto` (`resto_id`, `nom_resto`, `image_resto`, `localisation_resto`, `description_resto`, `tel_resto`) VALUES
(1, 'chez ishiraku', '../images/img_resto/ishiraku.png', 'cotonou', 'Ne ratez pas les specialites', '78451285'),
(2, 'chez bijoux', '../images/img_resto/chez_bijou.jpg', 'cotonou', 'chez bijoux, retrouvez des tresores inoubliable', '45781236'),
(3, 'le bateau_pirate', '../images/img_resto/bateau_pirate.jpeg', 'ganvie (la venise d\'Afrique)', 'Partez à l\'arbordage et decouvrez de nouvelle saveur', '45859632'),
(4, 'le domaine de la mer', '../images/img_resto/mer.jpeg', 'ganvie (la venise d\'Afrique)', 'Partez à la  decouvette de nouvelle saveur et douceur des mers', '45781225'),
(5, 'food war', '../images/img_resto/food_war.jpg', 'calavi', 'C\'est la guerre des saveurs', '12365478'),
(6, 'food', '../images/img_resto/food.jpg', 'seme city', 'Food Food venez decouvrir le foooood', '46985124'),
(7, 'ramen', '../images/img_resto/ramen.jpg', 'natitingou', 'Des ramens encore des ramens', '4785123348');

-- --------------------------------------------------------

--
-- Structure de la table `recette`
--

DROP TABLE IF EXISTS `recette`;
CREATE TABLE IF NOT EXISTS `recette` (
  `recette_id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_recette` varchar(255) NOT NULL,
  `image_recette` varchar(255) NOT NULL,
  `ingredient` text NOT NULL,
  `date_de_publication` date DEFAULT NULL,
  `description_recette` text NOT NULL,
  PRIMARY KEY (`recette_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `recette`
--

INSERT INTO `recette` (`recette_id`, `nom_recette`, `image_recette`, `ingredient`, `date_de_publication`, `description_recette`) VALUES
(1, 'blancs de poulet legers au yaourt et citron', '../images/recette_img/blancs_de_poulet.jpg', '<ul>\r\n<li>les blancs de poulet</li>\r\n<li>2 yaourts</li>\r\n<li>citron vert</li>\r\n<li>sel</li>\r\n<li>poivre</li>\r\n\r\n</ul>', '2022-05-08', '<p>\r\nUne heure avant la cuisson, coupez les blancs de poulet en dés d’environ 3 cm de côté. Mettez-les dans un saladier. Ajoutez les 2 yaourts, le zeste du citron vert, salez et poivrez. Mélangez et réservez au réfrigérateur pendant environ 1 heure.\r\n</p>\r\n<p>\r\nUne heure après, préchauffez votre four à 150°C. Étalez les dés de poulet sur une plaque de cuisson anti adhésive ou dans un plat mais il ne faut pas que le poulet soit sur plusieurs épaisseurs. Enfournez pour 15 minutes. Vérifiez la cuisson du poulet en coupant un dé en deux. Suivant la taille, il peut mettre 5 minutes de plus à cuire.\r\n</p>\r\n\r\n<p>\r\nA la sortie du four, pressez le jus du citron vert sur le poulet, salez et poivrez à nouveau. Accompagnez de légumes puis, servez bien chaud.\r\n</p>\r\n'),
(2, 'croque-monsieur au saumon', '../images/recette_img/croque-monsieur-au-saumon.jpg', '<ul>\r\n<li>pain de mie</li>\r\n<li>beurre</li>\r\n<li> crème épaisse</li>\r\n<li>le saumon</li>\r\n<li>tranche de cheddar</li>\r\n<li>la salade</li>\r\n\r\n</ul>', '2022-05-10', '<p>\r\nBeurrez les tranches de pain de mie sur une face.\r\n</p>\r\n<p>\r\nSur le côté non beurré, mettre un peu de crème épaisse, puis répartissez le saumon.\r\n</p>\r\n<p>\r\nRecouvrez d\'une tranche de cheddar, et terminez par la salade.\r\n</p>\r\n\r\n<p>\r\nRefermez les croques-monsieur et faites-les cuire dans un appareil à croques-monsieur ou au grill quelques instants.\r\n</p>\r\nDégustez votre croque-monsieur au saumon tiède.\r\n<p>\r\n\r\n</p>');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_debut_reservation` date DEFAULT NULL,
  `heure_debut` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `resto_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `resto_id` (`resto_id`),
  KEY `table_id` (`table_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reservation`
--

INSERT INTO `reservation` (`id`, `date_debut_reservation`, `heure_debut`, `user_id`, `table_id`, `resto_id`) VALUES
(1, '2022-05-11', 12, 1, 1, 1),
(2, '2022-05-11', 12, 1, 1, 1),
(3, '2022-05-11', 12, 1, 1, 1),
(4, '2022-05-11', 12, 1, 1, 1),
(5, '2022-05-11', 12, 1, 1, 1),
(6, '2022-05-11', 12, 1, 1, 1),
(7, '2022-05-11', 12, 1, 1, 1),
(8, '2022-05-11', 12, 1, 1, 1),
(9, '2022-06-11', 12, 1, 1, 1),
(10, '2022-05-11', 12, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `table_resto`
--

DROP TABLE IF EXISTS `table_resto`;
CREATE TABLE IF NOT EXISTS `table_resto` (
  `table_id` int(11) NOT NULL AUTO_INCREMENT,
  `num_table` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `categori` varchar(255) NOT NULL,
  `etat_table` tinyint(1) NOT NULL DEFAULT '0',
  `resto_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`table_id`),
  KEY `user_id` (`user_id`),
  KEY `resto_id` (`resto_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `table_resto`
--

INSERT INTO `table_resto` (`table_id`, `num_table`, `type`, `categori`, `etat_table`, `resto_id`, `user_id`) VALUES
(1, 1, '1 personne', 'Simple', 1, 1, 1),
(2, 2, '2 personnes', 'Simple', 1, 1, NULL),
(3, 3, '5 personnes', 'Simple', 0, 1, NULL),
(4, 4, '10 personnes', 'Occase', 0, 1, NULL),
(5, 1, '2 personnes', 'Simple', 0, 3, NULL),
(6, 2, '4 personnes', 'Simple', 1, 3, NULL),
(7, 3, '5 personnes', 'Simple', 1, 3, NULL),
(8, 4, '10 personnes', 'Occase', 0, 3, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `photo_profile` varchar(255) NOT NULL DEFAULT '../images/profile/default.jpg',
  `permission` tinyint(1) NOT NULL DEFAULT '0',
  `localisation_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`user_id`, `name`, `prenom`, `username`, `telephone`, `email`, `password`, `photo_profile`, `permission`, `localisation_user`) VALUES
(1, 'uzumaki', 'naruto', 'judi', '315874522', 'naruto@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '../images/profile/default.jpg', 2, 'cotonou'),
(2, 'yamanaka', 'ino', 'judicael', '457825698', 'ino@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '../images/profile/default.jpg', 1, NULL),
(3, 'nara', 'shikamaru', 'iudhael', '45782478555', 'nara@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '../images/profile/default.jpg', 0, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
